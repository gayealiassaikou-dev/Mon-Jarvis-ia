import unicodedata
import os
import difflib
import re
import json
import requests
import base64
import shutil

DOSSIER_AUTORISE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def _chemin_autorise(chemin_complet):
    chemin_reel = os.path.realpath(chemin_complet)
    dossier_reel = os.path.realpath(DOSSIER_AUTORISE)

    try:
        return os.path.commonpath(
            [chemin_reel, dossier_reel]
        ) == dossier_reel
    except ValueError:
        return False

FICHIERS_PROTEGES = [
    os.path.join(DOSSIER_AUTORISE, ".env"),
    os.path.join(DOSSIER_AUTORISE, ".git"),
]

DOSSIERS_PROTEGES = [
    os.path.join(DOSSIER_AUTORISE, "core"),
    os.path.join(DOSSIER_AUTORISE, ".git"),
]

def _fichier_protege(chemin_complet):
    for proteg in FICHIERS_PROTEGES:
        if chemin_complet == proteg:
            return True
    for dossier in DOSSIERS_PROTEGES:
        try:
            if os.path.commonpath([chemin_complet, dossier]) == dossier:
                return True
        except ValueError:
            continue
    return False


def _normaliser_nom_chemin(valeur):
    texte = unicodedata.normalize("NFKD", str(valeur))
    texte = texte.encode("ascii", "ignore").decode("ascii").lower()
    texte = texte.replace("\\", "/")
    mots = []
    for partie in texte.split("/"):
        partie = re.sub(r"^\d+[\s._-]*", "", partie)
        partie = re.sub(r"[_\-.]+", " ", partie)
        mots.extend(re.findall(r"[a-z0-9]+", partie))
    stop = {"de", "du", "des", "la", "le", "les", "un", "une", "d", "l", "a", "au", "aux", "et"}
    return " ".join(m for m in mots if m not in stop)


def _chercher_dossiers_similaires(dossier, limite=5):
    """Recherche des chemins proches, fichiers compris, dans le projet autorisé."""
    cible = _normaliser_nom_chemin(dossier)
    if not cible:
        return []

    exclusions = {
        ".git", ".patches", ".venv", "venv", "env", "node_modules",
        "__pycache__", ".pytest_cache"
    }
    resultats = []

    for racine, sous_dossiers, fichiers in os.walk(
        DOSSIER_AUTORISE, topdown=True, followlinks=False
    ):
        sous_dossiers[:] = [
            nom for nom in sous_dossiers
            if nom not in exclusions
            and _chemin_autorise(os.path.realpath(os.path.join(racine, nom)))
            and not _fichier_protege(os.path.realpath(os.path.join(racine, nom)))
        ]

        for nom in sous_dossiers + fichiers:
            chemin = os.path.join(racine, nom)
            reel = os.path.realpath(chemin)
            if not _chemin_autorise(reel) or _fichier_protege(reel):
                continue

            relatif = os.path.relpath(chemin, DOSSIER_AUTORISE)
            base = os.path.splitext(nom)[0] if os.path.isfile(chemin) else nom
            nom_normalise = _normaliser_nom_chemin(base)
            chemin_normalise = _normaliser_nom_chemin(
                os.path.splitext(relatif)[0] if os.path.isfile(chemin) else relatif
            )

            candidats = [x for x in (nom_normalise, chemin_normalise) if x]
            if not candidats:
                continue

            score = max(
                difflib.SequenceMatcher(None, cible, candidat).ratio()
                for candidat in candidats
            )

            mots_cible = cible.split()
            mots_nom = nom_normalise.split()
            if mots_cible and mots_nom:
                correspondance = sum(
                    1.0 if mot in mots_nom else max(
                        difflib.SequenceMatcher(None, mot, autre).ratio()
                        for autre in mots_nom
                    )
                    for mot in mots_cible
                ) / len(mots_cible)
                score = max(score, correspondance)

            if score >= 0.50:
                resultats.append((score, relatif))

    resultats.sort(key=lambda item: (-item[0], item[1].lower()))
    return [chemin for _, chemin in resultats[:limite]]

def creer_parent_manquant_pour_ecriture(chemin):
    """Cree un seul dossier parent manquant dans le projet autorise."""
    if not isinstance(chemin, str) or not chemin:
        return False

    chemin_complet = os.path.abspath(
        os.path.join(DOSSIER_AUTORISE, chemin)
    )
    if not _chemin_autorise(chemin_complet):
        return False

    chemin_reel = os.path.realpath(chemin_complet)
    if not _chemin_autorise(chemin_reel):
        return False
    if _fichier_protege(chemin_reel):
        return False
    if os.path.exists(chemin_reel):
        return False

    parent = os.path.dirname(chemin_reel)
    if os.path.isdir(parent) or not _chemin_autorise(parent):
        return False

    parent_reel = os.path.realpath(parent)
    if not _chemin_autorise(parent_reel):
        return False
    if _fichier_protege(parent_reel):
        return False

    parent_du_parent = os.path.dirname(parent_reel)
    if not os.path.isdir(parent_du_parent):
        return False
    if not _chemin_autorise(parent_du_parent):
        return False

    try:
        os.mkdir(parent_reel)
        return True
    except OSError:
        return False


def lire_fichier(chemin):
    chemin_complet = os.path.abspath(os.path.join(DOSSIER_AUTORISE, chemin))

    if not _chemin_autorise(chemin_complet):
        return "Erreur : accès refusé en dehors du projet."

    chemin_reel = os.path.realpath(chemin_complet)

    if _fichier_protege(chemin_reel):
        return "Erreur : accès refusé, fichier ou dossier protégé."

    if not os.path.exists(chemin_reel):
        return f"Erreur : le fichier {chemin} n'existe pas."

    with open(chemin_reel, "r", encoding="utf-8") as f:
        return f.read()

def ecrire_fichier(chemin, contenu):
    chemin_complet = os.path.abspath(os.path.join(DOSSIER_AUTORISE, chemin))

    if not _chemin_autorise(chemin_complet):
        return "Erreur : accès refusé en dehors du projet."

    chemin_reel = os.path.realpath(chemin_complet)
    if not _chemin_autorise(chemin_reel):
        return "Erreur : accès refusé en dehors du projet."

    if _fichier_protege(chemin_reel):
        return f"Erreur : {chemin} est un fichier protege, modification refusee."

    dossier_parent = os.path.dirname(chemin_reel)
    if not os.path.isdir(dossier_parent):
        return f"Erreur : le dossier parent de {chemin} n'existe pas. Creez d'abord le dossier cible."

    if os.path.isdir(chemin_reel):
        return f"Erreur : {chemin} est un dossier, pas un fichier."

    if not isinstance(contenu, str):
        return "Erreur : le contenu du fichier doit être du texte."

    try:
        with open(chemin_reel, "w", encoding="utf-8") as f:
            f.write(contenu)

        with open(chemin_reel, "r", encoding="utf-8") as f:
            if f.read() != contenu:
                return f"Erreur : vérification échouée après écriture de {chemin}."

        return f"Fichier {chemin} écrit et vérifié avec succès."
    except (OSError, UnicodeError) as exc:
        return f"Erreur : impossible d'écrire ou de vérifier {chemin} : {exc}"

def supprimer_fichier(chemin):
    chemin_complet = os.path.abspath(os.path.join(DOSSIER_AUTORISE, chemin))
    if not _chemin_autorise(chemin_complet):
        return "Erreur : accès refusé en dehors du projet."
    if _fichier_protege(chemin_complet):
        return f"Erreur : {chemin} est un fichier protege, suppression refusee."
    if not os.path.exists(chemin_complet):
        return f"Erreur : le fichier {chemin} n'existe pas, rien a supprimer."
    os.remove(chemin_complet)
    return f"Fichier {chemin} supprime avec succes."



def supprimer_dossier(chemin):
    """Supprime un dossier du projet après validation des protections."""
    if not isinstance(chemin, str) or not chemin.strip():
        return "Erreur : chemin du dossier absent."

    chemin = chemin.strip()
    chemin_complet = os.path.abspath(
        os.path.join(DOSSIER_AUTORISE, chemin)
    )
    chemin_reel = os.path.realpath(chemin_complet)
    racine_reelle = os.path.realpath(DOSSIER_AUTORISE)

    if not _chemin_autorise(chemin_complet):
        return "Erreur : accès refusé en dehors du projet."

    if chemin_reel == racine_reelle:
        return "Erreur : la racine du projet ne peut pas être supprimée."

    chemin_relatif = os.path.relpath(chemin_complet, DOSSIER_AUTORISE)
    chemin_verifie = DOSSIER_AUTORISE

    for composant in chemin_relatif.split(os.sep):
        if composant in ("", "."):
            continue
        chemin_verifie = os.path.join(chemin_verifie, composant)
        if os.path.islink(chemin_verifie):
            return "Erreur : les chemins contenant un lien symbolique ne peuvent pas être supprimés."


    if _fichier_protege(chemin_reel):
        return f"Erreur : {chemin} est un chemin protégé."

    if not os.path.exists(chemin_reel):
        return f"Erreur : le dossier {chemin} n'existe pas."

    if not os.path.isdir(chemin_reel):
        return f"Erreur : {chemin} n'est pas un dossier."

    try:
        shutil.rmtree(chemin_reel)
        return f"Dossier {chemin} supprimé avec succès."
    except OSError as exc:
        return f"Erreur : impossible de supprimer le dossier {chemin} : {exc}"

def lister_fichiers_original_en_ligne(dossier="."):
    chemin_complet = os.path.abspath(os.path.join(DOSSIER_AUTORISE, dossier))

    if not _chemin_autorise(chemin_complet):
        return "Erreur : accès refusé en dehors du projet."

    chemin_reel = os.path.realpath(chemin_complet)

    if _fichier_protege(chemin_reel):
        return "Erreur : accès refusé, dossier protégé."

    if not os.path.exists(chemin_reel):
        suggestions = _chercher_dossiers_similaires(dossier)
        if suggestions:
            liste = "\n".join(f"- {x}" for x in suggestions)
            return (
                f"Aucun dossier exact nommé '{dossier}' n'existe. "
                f"Chemins proches trouvés (fichiers et dossiers) :\n{liste}\n"
                "Vérifie le chemin proposé avant de réessayer. "
                "Aucun fichier ni dossier n'a été ouvert automatiquement."
            )
        return f"Erreur : le dossier {dossier} n'existe pas et aucun dossier proche n'a été trouvé."

    if not os.path.isdir(chemin_reel):
        return f"Erreur : {dossier} n'est pas un dossier."

    elements = os.listdir(chemin_reel)

    if not elements:
        return f"Le dossier {dossier} est vide."

    return "\n".join(sorted(elements))


import functools as _ft
@_ft.wraps(lister_fichiers_original_en_ligne)
def lister_fichiers(*args, **kwargs):
    r = lister_fichiers_original_en_ligne(*args, **kwargs)
    if isinstance(r, str):
        return '[Contenu des fichiers du serveur de Sam Sarr, PAS du depot GitHub]\n' + r
    return r

def creer_dossier(chemin):
    chemin_complet = os.path.abspath(os.path.join(DOSSIER_AUTORISE, chemin))

    if not _chemin_autorise(chemin_complet):
        return "Erreur : accès refusé en dehors du projet."

    chemin_reel = os.path.realpath(chemin_complet)

    if _fichier_protege(chemin_reel):
        return "Erreur : création refusée dans un dossier protégé."

    if os.path.exists(chemin_reel):
        return f"Le dossier {chemin} existe deja."

    os.makedirs(chemin_reel)

    return f"Dossier {chemin} cree avec succes."

def rechercher_web(requete):
    api_key = os.getenv("TAVILY_API_KEY")
    if not api_key:
        return "Erreur : cle API Tavily manquante (verifie le fichier .env)."

    url = "https://api.tavily.com/search"
    payload = {
        "api_key": api_key,
        "query": requete,
        "max_results": 3
    }
    try:
        reponse = requests.post(url, json=payload, timeout=15)
        if reponse.status_code == 401:
            return "Erreur : cle API Tavily invalide ou expiree."
        if reponse.status_code == 429:
            return "Erreur : limite de requetes Tavily atteinte, reessaie plus tard."
        if reponse.status_code != 200:
            return f"Erreur recherche web : code {reponse.status_code}."

        data = reponse.json()
        resultats = data.get("results", [])
        texte = ""
        for r in resultats:
            texte += f"- {r.get('title')}: {r.get('content')[:200]}\n"
        return texte if texte else "Aucun resultat trouve pour cette recherche."
    except requests.exceptions.Timeout:
        return "Erreur : la recherche web a expire (timeout)."
    except requests.exceptions.ConnectionError:
        return "Erreur : impossible de se connecter a Tavily (verifie ta connexion internet)."
    except Exception as e:
        return f"Erreur recherche web inattendue : {e}"

CHEMIN_DONNEES = os.path.join(DOSSIER_AUTORISE, "data", "projets_taches.json")
CHEMIN_PROJET_ACTIF = os.path.join(DOSSIER_AUTORISE, "data", "projet_actif.json")

def _charger_donnees():
    if not os.path.exists(CHEMIN_DONNEES):
        return {"projets": [], "taches": []}
    try:
        with open(CHEMIN_DONNEES, "r", encoding="utf-8") as f:
            donnees = json.load(f)
            donnees.setdefault("projets", [])
            donnees.setdefault("taches", [])
            return donnees
    except (json.JSONDecodeError, ValueError):
        return {"projets": [], "taches": []}

def _sauvegarder_donnees(donnees):
    os.makedirs(os.path.dirname(CHEMIN_DONNEES), exist_ok=True)
    with open(CHEMIN_DONNEES, "w", encoding="utf-8") as f:
        json.dump(donnees, f, indent=4, ensure_ascii=False)


def lire_etat_projets_taches():
    """Retourne l'etat structure des projets et des taches."""
    return _charger_donnees()

def creer_projet(nom):
    donnees = _charger_donnees()
    for p in donnees["projets"]:
        if p["nom"].strip().lower() == nom.strip().lower():
            return f"Erreur : le projet '{nom}' existe deja."
    donnees["projets"].append({"nom": nom, "statut": "en cours"})
    _sauvegarder_donnees(donnees)
    return f"Projet '{nom}' cree avec succes."

def ajouter_tache(nom, projet=""):
    donnees = _charger_donnees()
    for t in donnees["taches"]:
        if t["nom"].strip().lower() == nom.strip().lower() and t["projet"].strip().lower() == projet.strip().lower():
            return f"Erreur : la tache '{nom}' existe deja pour ce projet."
    donnees["taches"].append({"nom": nom, "projet": projet, "statut": "en attente"})
    _sauvegarder_donnees(donnees)
    return f"Tache '{nom}' ajoutee avec succes."

def lister_projets():
    donnees = _charger_donnees()
    if not donnees["projets"]:
        return "Aucun projet enregistre."
    texte = ""
    for p in donnees["projets"]:
        texte += f"- {p['nom']} ({p['statut']})\n"
    return texte

def definir_projet_actif(nom):
    """Selectionne un projet existant et memorise son nom."""
    if not isinstance(nom, str) or not nom.strip():
        return "Erreur : nom de projet invalide."

    donnees = _charger_donnees()
    for projet in donnees.get("projets", []):
        if not isinstance(projet, dict):
            continue
        nom_projet = projet.get("nom", "")
        if isinstance(nom_projet, str) and nom_projet.strip().lower() == nom.strip().lower():
            os.makedirs(os.path.dirname(CHEMIN_PROJET_ACTIF), exist_ok=True)
            with open(CHEMIN_PROJET_ACTIF, "w", encoding="utf-8") as f:
                json.dump({"nom": nom_projet.strip()}, f, ensure_ascii=False, indent=4)
            return f"Projet actif selectionne : {nom_projet.strip()}."

    return f"Erreur : le projet '{nom.strip()}' n'existe pas."


def _obtenir_nom_projet_actif():
    """Retourne le nom exact du projet actif, ou None si invalide."""
    try:
        with open(CHEMIN_PROJET_ACTIF, "r", encoding="utf-8") as f:
            actif = json.load(f)
        nom = actif.get("nom", "")
        if not isinstance(nom, str) or not nom.strip():
            return None

        for projet in _charger_donnees().get("projets", []):
            if isinstance(projet, dict):
                nom_projet = projet.get("nom", "")
                if isinstance(nom_projet, str) and nom_projet.strip().lower() == nom.strip().lower():
                    return nom_projet.strip()
    except (OSError, json.JSONDecodeError, AttributeError):
        return None
    return None


def obtenir_projet_actif():
    """Retrouve le projet actif memorise et verifie qu'il existe encore."""
    if not os.path.exists(CHEMIN_PROJET_ACTIF):
        return "Aucun projet actif selectionne."

    try:
        with open(CHEMIN_PROJET_ACTIF, "r", encoding="utf-8") as f:
            donnees_actives = json.load(f)
        nom = donnees_actives.get("nom", "")
        if not isinstance(nom, str) or not nom.strip():
            return "Erreur : fichier du projet actif invalide."

        for projet in _charger_donnees().get("projets", []):
            if isinstance(projet, dict):
                nom_projet = projet.get("nom", "")
                if isinstance(nom_projet, str) and nom_projet.strip().lower() == nom.strip().lower():
                    return f"Projet actif : {nom_projet.strip()}."

        return f"Le projet memorise '{nom}' n'existe plus dans la liste des projets."
    except (OSError, json.JSONDecodeError, AttributeError):
        return "Erreur : impossible de lire le projet actif."


def lister_taches():
    donnees = _charger_donnees()
    if not donnees["taches"]:
        return "Aucune tache enregistree."
    texte = ""
    for t in donnees["taches"]:
        texte += f"- {t['nom']} [{t['statut']}]"
        if t["projet"]:
            texte += f" (projet: {t['projet']})"
        texte += "\n"
    return texte

def _headers_github():
    token = os.getenv("GITHUB_TOKEN")
    return {"Authorization": f"token {token}", "Accept": "application/vnd.github+json"}

def _interpreter_erreur_github(status_code, contexte=""):
    if status_code == 401:
        return "Erreur : token GitHub invalide ou expire."
    if status_code == 403:
        return "Erreur : acces refuse ou limite de requetes GitHub atteinte."
    if status_code == 404:
        return f"Erreur : {contexte} introuvable sur GitHub."
    return f"Erreur GitHub : code {status_code}."


def github_creer_repo_original_en_ligne(nom, description="", public=True):
    """
    Cree ou retrouve un depot GitHub via l'authentification locale de gh.

    L'operation est idempotente : si le depot existe deja avec la bonne
    visibilite, l'operation est consideree comme reussie.
    """
    import subprocess

    if not isinstance(nom, str) or not nom.strip():
        return "Erreur : le nom du depot est obligatoire."

    nom = nom.strip()

    if len(nom) > 100:
        return "Erreur : le nom du depot est trop long."

    if any(caractere in nom for caractere in (
        "/", "\\", " ", "\t", "\n", "\r", '"', "'", "`", "$"
    )):
        return "Erreur : nom de depot invalide."

    if not all(
        caractere.isalnum() or caractere in "-_."
        for caractere in nom
    ):
        return "Erreur : nom de depot invalide."

    if not isinstance(description, str):
        return "Erreur : la description doit etre une chaine."

    if len(description) > 500:
        return "Erreur : la description est trop longue."

    if not isinstance(public, bool):
        return "Erreur : public doit etre booleen."

    # Etape 1 : verifier si le depot existe deja.
    existant = subprocess.run(
        [
            "gh",
            "repo",
            "view",
            nom,
            "--json",
            "nameWithOwner,url,isPrivate",
        ],
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )

    if existant.returncode == 0:
        donnees = existant.stdout.strip()

        try:
            import json
            depot = json.loads(donnees)
        except json.JSONDecodeError:
            return (
                "Erreur : GitHub a retourne une reponse invalide "
                "lors de la verification du depot existant."
            )

        est_prive = depot.get("isPrivate")
        visibilite_attendue = not public

        if est_prive != visibilite_attendue:
            visibilite = "prive" if est_prive else "public"
            attendue = "prive" if not public else "public"
            return (
                f"Erreur : le depot {depot.get('nameWithOwner', nom)} "
                f"existe deja mais il est {visibilite}. "
                f"La demande exige un depot {attendue}."
            )

        return (
            f"Depot GitHub deja existant et verifie : "
            f"{donnees}"
        )

    # Le depot n'existe pas : on peut le creer.
    visibilite = "public" if public else "private"

    commande = [
        "gh",
        "repo",
        "create",
        nom,
        f"--{visibilite}",
        "--description",
        description,
    ]

    try:
        resultat = subprocess.run(
            commande,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except FileNotFoundError:
        return "Erreur : GitHub CLI 'gh' est introuvable."
    except subprocess.TimeoutExpired:
        return "Erreur : la creation du depot GitHub a expire."
    except OSError as erreur:
        return (
            "Erreur systeme GitHub CLI : "
            f"{type(erreur).__name__}: {erreur}"
        )

    sortie = (resultat.stdout or "").strip()
    erreur = (resultat.stderr or "").strip()

    if resultat.returncode != 0:
        details = erreur or sortie or "aucun detail fourni par gh"
        return f"Erreur creation depot GitHub : {details}"

    # Verification reelle apres creation.
    verification = subprocess.run(
        [
            "gh",
            "repo",
            "view",
            nom,
            "--json",
            "nameWithOwner,url,isPrivate",
        ],
        capture_output=True,
        text=True,
        timeout=30,
        check=False,
    )

    if verification.returncode != 0:
        details = (
            verification.stderr.strip()
            or verification.stdout.strip()
            or "verification impossible"
        )
        return (
            "Erreur : le depot semble avoir ete cree, "
            f"mais sa verification a echoue : {details}"
        )

    return (
        f"Depot GitHub cree et verifie avec succes : "
        f"{verification.stdout.strip()}"
    )


import functools as _ft
@_ft.wraps(github_creer_repo_original_en_ligne)
def github_creer_repo(*args, **kwargs):
    import shutil as _sh
    if not _sh.which('gh'):
        return "Erreur : cet outil GitHub n'est pas disponible en ligne (la commande gh n'est installee que sur le telephone). Aucune action effectuee."
    return github_creer_repo_original_en_ligne(*args, **kwargs)

def github_lister_repos_original_en_ligne():
    url = "https://api.github.com/user/repos"
    try:
        r = requests.get(url, headers=_headers_github(), timeout=15)
        if r.status_code != 200:
            return _interpreter_erreur_github(r.status_code, "les depots")
        repos = r.json()
        if not repos:
            return "Aucun depot trouve."
        return "\n".join(f"- {repo['full_name']}" for repo in repos)
    except requests.exceptions.Timeout:
        return "Erreur : la connexion a GitHub a expire (timeout)."
    except requests.exceptions.ConnectionError:
        return "Erreur : impossible de se connecter a GitHub (verifie ta connexion internet)."
    except Exception as e:
        return f"Erreur GitHub inattendue : {e}"


import functools as _ft
@_ft.wraps(github_lister_repos_original_en_ligne)
def github_lister_repos(*args, **kwargs):
    import os as _os
    if not _os.getenv('GITHUB_TOKEN'):
        return 'Erreur : GITHUB_TOKEN est absent, impossible de lister les depots GitHub depuis ce serveur. Aucune action effectuee.'
    return github_lister_repos_original_en_ligne(*args, **kwargs)


def _github_resoudre_repo(repo):
    """Resout un depot GitHub et retourne son nom et le token disponible."""
    token = os.getenv("GITHUB_TOKEN", "").strip()

    if not isinstance(repo, str) or not repo.strip():
        return None, None, "Erreur : le depot GitHub est obligatoire."

    repo = repo.strip()

    if "/" not in repo:
        if not token:
            return None, None, (
                "Erreur : indique le depot sous la forme proprietaire/depot. "
                "Un GITHUB_TOKEN est necessaire pour resoudre un nom court."
            )
        try:
            reponse = requests.get(
                "https://api.github.com/user",
                headers=_github_entetes(token),
                timeout=15,
            )
        except requests.RequestException:
            return None, None, "Erreur : connexion a GitHub impossible."

        if reponse.status_code != 200:
            return None, None, (
                "Erreur GitHub : impossible de verifier le compte "
                f"(HTTP {reponse.status_code})."
            )

        repo = f"{reponse.json().get('login', '')}/{repo}"

    morceaux = repo.split("/")
    if (
        len(morceaux) != 2
        or not all(morceaux)
        or any(
            not re.fullmatch(r"[A-Za-z0-9_.-]+", partie)
            for partie in morceaux
        )
    ):
        return None, None, (
            "Erreur : depot invalide. Utilise proprietaire/depot."
        )

    return repo, token, None


def _github_entetes(token=None):
    entetes = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        entetes["Authorization"] = f"Bearer {token}"
    return entetes


def _github_message_erreur(reponse):
    try:
        message = reponse.json().get("message")
    except (ValueError, AttributeError):
        message = None
    return str(message or "aucun detail fourni par GitHub")[:300]


def github_lire_fichier_original_en_ligne(repo, chemin):
    """Lit un fichier GitHub avec l'API REST officielle."""
    if not isinstance(chemin, str) or not chemin.strip():
        return "Erreur : le chemin du fichier est obligatoire."

    chemin = chemin.strip().replace("\\", "/")
    if chemin.startswith("/") or ".." in chemin.split("/"):
        return "Erreur : chemin de fichier invalide."

    repo, token, erreur = _github_resoudre_repo(repo)
    if erreur:
        return erreur

    from urllib.parse import quote
    url = (
        "https://api.github.com/repos/"
        + quote(repo, safe="/")
        + "/contents/"
        + quote(chemin, safe="/")
    )

    try:
        reponse = requests.get(
            url, headers=_github_entetes(token), timeout=20
        )
    except requests.RequestException:
        return "Erreur : connexion a GitHub impossible pendant la lecture."

    if reponse.status_code != 200:
        return (
            f"Erreur lecture GitHub (HTTP {reponse.status_code}) : "
            f"{_github_message_erreur(reponse)}"
        )

    try:
        donnees = reponse.json()
        if donnees.get("type") != "file":
            return "Erreur : le chemin indique n'est pas un fichier."
        contenu = donnees.get("content", "")
        if not contenu:
            return "Erreur : GitHub n'a retourne aucun contenu."
        return base64.b64decode(contenu).decode("utf-8")
    except (ValueError, UnicodeDecodeError, TypeError, AttributeError):
        return "Erreur : contenu GitHub invalide ou non decodable."


def github_lire_fichier(*args, **kwargs):
    return github_lire_fichier_original_en_ligne(*args, **kwargs)


def github_ecrire_fichier_original_en_ligne(
    repo, chemin, contenu, message="Mise a jour via Sam Sarr"
):
    """Cree ou met a jour un fichier GitHub via l'API REST."""
    if not isinstance(chemin, str) or not chemin.strip():
        return "Erreur : le chemin du fichier est obligatoire."
    if not isinstance(contenu, str):
        return "Erreur : le contenu du fichier doit etre une chaine."
    if not isinstance(message, str) or not message.strip():
        return "Erreur : le message du commit est obligatoire."

    chemin = chemin.strip().replace("\\", "/")
    if chemin.startswith("/") or ".." in chemin.split("/"):
        return "Erreur : chemin de fichier invalide."

    repo, token, erreur = _github_resoudre_repo(repo)
    if erreur:
        return erreur
    if not token:
        return (
            "Erreur : GITHUB_TOKEN est absent. "
            "Configure-le dans les variables d'environnement de Velixir."
        )

    from urllib.parse import quote
    url = (
        "https://api.github.com/repos/"
        + quote(repo, safe="/")
        + "/contents/"
        + quote(chemin, safe="/")
    )
    entetes = _github_entetes(token)

    try:
        lecture = requests.get(url, headers=entetes, timeout=20)
    except requests.RequestException:
        return "Erreur : connexion a GitHub impossible pendant la lecture."

    sha = None
    if lecture.status_code == 200:
        try:
            sha = lecture.json().get("sha")
        except (ValueError, AttributeError):
            return "Erreur : reponse GitHub invalide."
    elif lecture.status_code != 404:
        return (
            f"Erreur GitHub pendant la lecture (HTTP {lecture.status_code}) : "
            f"{_github_message_erreur(lecture)}"
        )

    donnees = {
        "message": message.strip(),
        "content": base64.b64encode(
            contenu.encode("utf-8")
        ).decode("ascii"),
    }
    if sha:
        donnees["sha"] = sha

    try:
        resultat = requests.put(
            url, headers=entetes, json=donnees, timeout=30
        )
    except requests.RequestException:
        return "Erreur : connexion a GitHub impossible pendant l'ecriture."

    if resultat.status_code not in (200, 201):
        return (
            f"Erreur ecriture GitHub (HTTP {resultat.status_code}) : "
            f"{_github_message_erreur(resultat)}"
        )

    return f"Fichier {chemin} envoye avec succes sur {repo}."


def github_ecrire_fichier(*args, **kwargs):
    return github_ecrire_fichier_original_en_ligne(*args, **kwargs)


def terminer_tache(nom):
    donnees = _charger_donnees()
    for t in donnees["taches"]:
        if t["nom"] == nom:
            t["statut"] = "terminee"
            _sauvegarder_donnees(donnees)
            return f"Tache '{nom}' marquee comme terminee."
    return f"Erreur : tache '{nom}' introuvable."

def supprimer_tache(nom):
    donnees = _charger_donnees()
    taille_avant = len(donnees["taches"])
    donnees["taches"] = [t for t in donnees["taches"] if t["nom"] != nom]
    if len(donnees["taches"]) == taille_avant:
        return f"Erreur : tache '{nom}' introuvable."
    _sauvegarder_donnees(donnees)
    return f"Tache '{nom}' supprimee avec succes."

def supprimer_projet(nom):
    import unicodedata
    from difflib import SequenceMatcher

    donnees = _charger_donnees()

    def normaliser_nom(valeur):
        texte = unicodedata.normalize("NFKD", str(valeur or "").strip().casefold())
        texte = "".join(c for c in texte if not unicodedata.combining(c))
        return " ".join(texte.split())

    nom_recherche = normaliser_nom(nom)
    projets_avant = donnees["projets"]

    correspondances = [
        p for p in projets_avant
        if isinstance(p, dict)
        and normaliser_nom(p.get("nom", "")) == nom_recherche
    ]

    if not correspondances:
        ressemblances = [
            str(p.get("nom", "")).strip()
            for p in projets_avant
            if isinstance(p, dict)
            and isinstance(p.get("nom"), str)
            and SequenceMatcher(
                None, nom_recherche, normaliser_nom(p["nom"])
            ).ratio() >= 0.70
        ]
        if ressemblances:
            return (
                f"Confirmation requise : le nom '{nom}' ne correspond pas exactement. "
                f"Projet ressemblant trouvé : {', '.join(ressemblances)}. "
                "Aucun projet n'a été supprimé. Confirme le nom exact."
            )
        return f"Erreur : projet '{nom}' introuvable."

    if len(correspondances) > 1:
        return (
            f"Erreur : plusieurs projets correspondent à '{nom}'. "
            "Aucun projet n'a été supprimé."
        )

    projet_cible = correspondances[0]
    donnees["projets"] = [
        p for p in projets_avant if p is not projet_cible
    ]
    _sauvegarder_donnees(donnees)
    return f"Projet '{projet_cible.get('nom', nom)}' supprime avec succes."

def modifier_statut_projet(nom, nouveau_statut):
    statuts_valides = ["en cours", "en pause", "termine", "annule"]
    if nouveau_statut.strip().lower() not in statuts_valides:
        return f"Erreur : statut invalide. Statuts valides : {', '.join(statuts_valides)}."
    donnees = _charger_donnees()
    for p in donnees["projets"]:
        if p["nom"].strip().lower() == nom.strip().lower():
            p["statut"] = nouveau_statut.strip().lower()
            _sauvegarder_donnees(donnees)
            return f"Projet '{nom}' passe au statut '{nouveau_statut}'."
    return f"Erreur : projet '{nom}' introuvable."



def analyser_erreur_python(traceback):
    """Analyse un traceback et affiche le code autour de l'erreur."""
    import re

    if not isinstance(traceback, str) or not traceback.strip():
        return "Erreur : aucun traceback fourni."

    texte = traceback.strip()
    correspondances = re.findall(
        r'File "([^"]+)", line (\d+)',
        texte
    )
    exception = re.search(
        r"^([A-Za-z_][A-Za-z0-9_.]*):\s*(.*)$",
        texte,
        re.MULTILINE
    )

    if not exception:
        return "Diagnostic incomplet : type d'erreur Python introuvable.\n" + texte[-4000:]

    type_erreur = exception.group(1).split(".")[-1]
    message = exception.group(2).strip()

    explications = {
        "ZeroDivisionError": "Une division a ete effectuee par zero.",
        "NameError": "Une variable ou un nom utilise n'est pas defini.",
        "TypeError": "Une operation a recu un type de donnee incompatible.",
        "IndexError": "Le programme tente d'acceder a un element hors des limites d'une liste ou sequence.",
        "KeyError": "Une cle demandee est absente d'un dictionnaire.",
        "AttributeError": "Un objet ne possede pas l'attribut ou la methode utilisee.",
        "FileNotFoundError": "Un fichier ou dossier demande est introuvable.",
        "ModuleNotFoundError": "Un module Python necessaire est introuvable.",
        "ImportError": "Un element necessaire n'a pas pu etre importe.",
        "ValueError": "Une valeur est incompatible avec l'operation demandee.",
        "PermissionError": "Le programme ne dispose pas des permissions necessaires.",
        "IndentationError": "L'indentation du code Python est incorrecte.",
        "SyntaxError": "Le code contient une erreur de syntaxe."
    }

    lignes = [
        "DIAGNOSTIC PYTHON",
        f"Type : {type_erreur}",
        f"Message : {message or 'Aucun detail fourni.'}",
        f"Cause probable : {explications.get(type_erreur, 'Une exception Python est survenue. Une analyse du code concerne est necessaire.')}"
    ]

    if correspondances:
        fichier_erreur, numero = correspondances[-1]
        numero = int(numero)
        lignes.extend([
            f"Fichier : {fichier_erreur}",
            f"Ligne : {numero}"
        ])

        racine = os.path.realpath(DOSSIER_AUTORISE)
        dossier_travail = os.path.realpath(os.path.join(racine, "espace_travail"))
        chemin_reel = os.path.realpath(fichier_erreur)

        try:
            dans_espace = os.path.commonpath(
                [chemin_reel, dossier_travail]
            ) == dossier_travail
        except ValueError:
            dans_espace = False

        if (
            dans_espace
            and chemin_reel.endswith(".py")
            and _chemin_autorise(chemin_reel)
            and not _fichier_protege(chemin_reel)
            and os.path.isfile(chemin_reel)
        ):
            try:
                with open(chemin_reel, "r", encoding="utf-8") as source:
                    contenu = source.readlines()

                if 1 <= numero <= len(contenu):
                    debut = max(1, numero - 5)
                    fin = min(len(contenu), numero + 5)
                    lignes.append("CONTEXTE DU CODE :")
                    for index in range(debut, fin + 1):
                        marqueur = ">" if index == numero else " "
                        lignes.append(
                            f"{marqueur} {index:4}: {contenu[index - 1].rstrip()}"
                        )
                else:
                    lignes.append("Contexte indisponible : numero de ligne invalide.")
            except (OSError, UnicodeError) as exc:
                lignes.append(f"Contexte indisponible : {exc}")
        else:
            lignes.append(
                "Contexte non lu : fichier hors de l'espace de travail autorise."
            )

    lignes.append(
        "Correction : a determiner en examinant le code et le contexte ci-dessus."
    )
    return "\\n".join(lignes)

def diagnostiquer_code_python(chemin):
    """Analyse la syntaxe Python sans executer le programme."""
    import ast

    if not isinstance(chemin, str) or not chemin.strip():
        return "Erreur : chemin absent."

    complet = os.path.abspath(os.path.join(DOSSIER_AUTORISE, chemin.strip()))
    reel = os.path.realpath(complet)

    if not _chemin_autorise(complet) or not _chemin_autorise(reel):
        return "Erreur : chemin en dehors du projet."

    if not reel.endswith(".py") or not os.path.isfile(reel):
        return "Erreur : fichier Python introuvable."

    try:
        with open(reel, "r", encoding="utf-8") as fichier:
            source = fichier.read()
        ast.parse(source, filename=reel)
        compile(source, reel, "exec")
        return f"SUCCES : aucune erreur de syntaxe dans {chemin}."
    except SyntaxError as exc:
        return (
            f"ERREUR DE SYNTAXE : {exc.msg}\n"
            f"Fichier : {chemin}\n"
            f"Ligne : {exc.lineno}\n"
            f"Colonne : {exc.offset}"
        )
    except (OSError, UnicodeError, ValueError) as exc:
        return f"Erreur de diagnostic : {exc}"



def _cible_python_espace_travail(chemin):
    """Valide une cible Python située dans espace_travail."""
    if not isinstance(chemin, str) or not chemin.strip():
        return None, None, "Erreur : chemin absent."

    dossier = os.path.realpath(
        os.path.join(DOSSIER_AUTORISE, "espace_travail")
    )
    complet = os.path.abspath(
        os.path.join(DOSSIER_AUTORISE, chemin.strip())
    )
    reel = os.path.realpath(complet)

    try:
        autorise = (
            os.path.commonpath([complet, dossier]) == dossier
            and os.path.commonpath([reel, dossier]) == dossier
        )
    except ValueError:
        autorise = False

    if not autorise:
        return None, None, "Erreur : fichier hors de espace_travail."

    if not _chemin_autorise(reel) or _fichier_protege(reel):
        return None, None, "Erreur : accès refusé."

    if not reel.endswith(".py") or not os.path.isfile(reel):
        return None, None, "Erreur : fichier Python introuvable."

    relatif = os.path.relpath(reel, DOSSIER_AUTORISE)
    return reel, relatif, None


def corriger_code_python(chemin, ancien_code, nouveau_code):
    """Remplace une occurrence exacte après validation syntaxique."""
    import ast

    reel, relatif, erreur = _cible_python_espace_travail(chemin)
    if erreur:
        return erreur

    if not isinstance(ancien_code, str) or not ancien_code:
        return "Erreur : ancien code absent ou invalide."

    if not isinstance(nouveau_code, str):
        return "Erreur : nouveau code invalide."

    try:
        with open(reel, "r", encoding="utf-8") as fichier:
            source = fichier.read()

        occurrences = source.count(ancien_code)
        if occurrences == 0:
            return "Erreur : ancien code introuvable. Aucune modification."
        if occurrences > 1:
            return f"Erreur : {occurrences} occurrences trouvées. Correction refusée."

        corrige = source.replace(ancien_code, nouveau_code, 1)

        ast.parse(corrige, filename=reel)
        compile(corrige, reel, "exec")

        return ecrire_fichier(relatif, corrige)

    except SyntaxError as exc:
        return (
            f"Correction refusée : erreur de syntaxe à la ligne "
            f"{exc.lineno} : {exc.msg}"
        )
    except (OSError, UnicodeError, ValueError) as exc:
        return f"Erreur pendant la correction : {exc}"


def reparer_syntaxe_python(chemin):
    """Répare uniquement un deux-points manquant sur une ligne reconnue."""
    import ast

    reel, relatif, erreur = _cible_python_espace_travail(chemin)
    if erreur:
        return erreur

    try:
        with open(reel, "r", encoding="utf-8") as fichier:
            source = fichier.read()

        try:
            ast.parse(source, filename=reel)
            compile(source, reel, "exec")
            return "SUCCES : aucune erreur de syntaxe à réparer."
        except SyntaxError as exc:
            if exc.msg != "expected ':'" or not exc.lineno:
                return (
                    f"Réparation impossible : {exc.msg}, "
                    f"ligne {exc.lineno}."
                )
            numero_ligne = exc.lineno

        lignes = source.splitlines(keepends=True)
        index = numero_ligne - 1

        if index < 0 or index >= len(lignes):
            return "Erreur : ligne fautive introuvable."

        ligne = lignes[index]
        contenu = ligne.rstrip("\r\n")
        fin = ligne[len(contenu):]

        motif = (
            r"^\s*(?:async\s+def|def|class|if|elif|else|for|while|"
            r"try|except|finally|with|async\s+with|match|case)\b.*\S$"
        )

        if "#" in contenu or not re.match(motif, contenu):
            return "Réparation refusée : ligne non reconnue avec certitude."

        lignes[index] = contenu + ":" + fin
        corrige = "".join(lignes)

        ast.parse(corrige, filename=reel)
        compile(corrige, reel, "exec")

        resultat = ecrire_fichier(relatif, corrige)
        return "Réparation syntaxique vérifiée. " + resultat

    except SyntaxError as exc:
        return f"Réparation refusée : {exc.msg}, ligne {exc.lineno}."
    except (OSError, UnicodeError, ValueError) as exc:
        return f"Erreur pendant la réparation : {exc}"


def executer_tests_python():
    """Execute toute la suite de tests pytest du depot."""
    import subprocess
    import sys

    dossier_tests = os.path.join(DOSSIER_AUTORISE, "tests")
    if not os.path.isdir(dossier_tests):
        return "Erreur : le dossier tests est introuvable."

    commande = [sys.executable, "-m", "pytest", "tests/", "-q"]

    try:
        resultat = subprocess.run(
            commande,
            cwd=DOSSIER_AUTORISE,
            capture_output=True,
            text=True,
            check=False
        )
    except subprocess.TimeoutExpired:
        return "Erreur : délai maximal de 90 secondes dépassé pendant l'exécution des tests pytest."
    except OSError as exc:
        return f"Erreur lors du lancement de pytest : {exc}"

    sortie = ((resultat.stdout or "") + "\n" + (resultat.stderr or "")).strip()
    sortie = sortie[-12000:]

    if resultat.returncode == 0:
        return "SUCCÈS : tous les tests pytest ont réussi.\n" + sortie

    return (
        f"ÉCHEC : pytest a retourné le code {resultat.returncode}.\n"
        + sortie
    )

def executer_programme_python(chemin):
    """Lance un programme Python depuis l'espace de travail."""
    from core.execution_python import executer_programme_python as executer
    return executer(chemin)
